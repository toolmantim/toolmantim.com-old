# An example class
class MyFirstDocumentedClass
  # A public method
  def a_public_method
  end
  # A public method
  def another_public_method
  end  
end

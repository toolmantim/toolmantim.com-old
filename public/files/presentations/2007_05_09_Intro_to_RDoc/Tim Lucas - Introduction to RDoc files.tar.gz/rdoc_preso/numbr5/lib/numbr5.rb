require 'rubygems'
require 'metaid'
require 'rice/irc'
require 'rice/observer'


BYEBYE  = 'byebye > '

module Numbr5
  Thread.abort_on_exception = true

  class << self
    def mk_observer(config)
      o = RICE::SimpleClient.new(config.nick, config.user, config.real, config.password, config.channel)
      class << o
        include RICE::Command
        include RICE::Reply

        #def response_for_rpl_welcome(subject, message)
        #  subject.push join('channel_name', 'password')
          # add as many channels as you want here.
        #end

        def response_for_join(subject, message)
          chan = message.params[0]
          # subject.push privmsg(chan, "tumblebee in the hizzouse!")
        end

        def response_for_privmsg(subject, message)
          nick = message.prefix.scan(/^[^!]+/o)[0]
          chan = message.params[0]
          text = message.params[1..-1].join(' ')
          
          puts "connected" if nick == 'freenode-connect' and chan == $config.nick
          
          case text
          when BYEBYE
            subject.push(quit) if nick == 'lachie' # ownage
          when /^#{@nick}[:,]\s+(.*)/
            response = Numbr5::Commands.process(self,$1,nick,chan)
            (Array === response ? response : [response]).compact.each do |r|
              subject.push privmsg(chan,r)
            end
            
          when /^\001ACTION\s+(.*?)\001/
            response = Numbr5::Actions.process(self,$1,nick,chan)
            (Array === response ? response : [response]).compact.each do |r|
              subject.push privmsg(chan,r)
            end
            
          else
            if chan == $config.channel
              messages = self.messages
              messages.pop if messages.size > 100
              messages.unshift [nick,text]
            end
          end
          
        rescue
          puts "something went wrong: #{$!}"
          puts $!.backtrace * "\n    "
        end
        
        def messages
          @messages ||= []
        end
        
        # def update(subject, type, message)
        #                          puts "got an update: #{type}"
        #                          puts "subject"
        #                          p subject
        #                          puts "message"
        #                          p message
        #                          puts
        #                          
        #                          super
        #                        end
        
        def uped(subject,message)
          puts "upped"
          super
        end
        
        def response_for_rpl_welcome(subject,message)
          puts "welcomed"
          super
        end

        def message(subject, message)
          # puts "message"
          # p subject
          # puts "subject"
          # p message
          # puts
        end

        def downed(subject, message)
        end
      end
      o
    end

    def connect(config)
      o = mk_observer(config)
      c = RICE::Connection.new('irc.freenode.net', 6667)
      c.add_observer(o)
      c
    end
  end
  
  module Commands
    class Base
      include Commands
      
      def self.match(text)
        return text unless self.cmd
        $1 if text[/^\?#{self.cmd.to_s}\s*(.*)$/]
      end
      
      def self.help_text
        "    #{self.cmd ? "?#{self.cmd}" : '(default)'} #{self.help rescue '(no help)'}"
      end
      
      def initialize()
      end
    end
    
    @commands = []
    @current_help = nil
    
    class << self
      def commands
        @commands
      end
      
      def help(help_text)
        @current_help = help_text
      end
      
      def choose(text)
        commands.sort_by do |c|
          p = c.priority || 0
          p == :fallback ? commands.size : p
          
        end.each do |c|
          matched = c.match(text) and return [c,matched]
        end
        
        [Usage,text]
      end
      
      def process(client,text,nick,chan)
        c,rem = self.choose(text)
        c.new.process(client,rem,nick,chan)
      end

      
      def C(pattern=nil,priority=nil,&block)
        
        priority ||= commands.size
        if ch = @current_help
          @current_help = nil
        end
        
        @commands << Class.new(Base) do
          meta_def(:help     ) {ch} if ch
          meta_def(:cmd      ) { pattern    }
          meta_def(:priority ) { priority   }
          class_def(:process,&block)
        end
      end
      
    end
    
    help "help"
    Usage = C :h do |client,text,nick,chan|
      help = ["numbr5 is here to help!"]
      help += Numbr5::Commands.commands.map {|c| c.help_text}.flatten
      help
    end
    
  end
  
  module Actions
    class Base
    end
    
    @actions = []
    class << self
      def actions
        @actions
      end
      
      def choose(text)
        @actions.each do |a|
          return a if text[a.pattern]
        end
        return nil
      end
      
      def process(client,text,nick,chan)
        c = self.choose(text)
        c.new.process(client,text,nick,chan)
      end
      
      def A(pattern,&block)
        @actions << Class.new(Base) do
          meta_def(:pattern) {pattern}
          class_def(:process,&block)
        end
      end
    end
  end
end
require 'curb'
require 'curb_core'
require 'hash_hasher'

module Faces
  class Client
    def initialize
      @host = 'http://faces.rubyonrails.com.au'
      
      @c = Curl::Easy.new("#{@host}/thankyous") do |c|
        c.enable_cookies = true
        c.cookiejar = "/tmp/faces.cookie"
        c.verbose = true # turn off
      end
    end
    
    def thank(from,to,reason)
      @c.url = "#{@host}/thankyous"

      params = {:from => from, :to => to, :reason => reason}
      params[:hash] = HashHasher.mk_hash($config.faces_secret,params)
      
      args = params.inject([]) {|args,(k,v)| args << Curl::PostField.content(k.to_s,v) }
      @c.http_post args
      
      @c.body_str
    end
    
  end
end
    
    
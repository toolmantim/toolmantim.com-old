require 'hpricot'
require 'open-uri'
require 'pp'

module Numbr5
  module Commands
    
    def tumblr_client
      t = Tumblr::Client.new
      t.signin($config.tumblr_user, $config.tumblr_pass)
      t
    end
    
    # pinched from erb
    def h(s)
      s.to_s.gsub(/&/, "&amp;").gsub(/\"/, "&quot;").gsub(/>/, "&gt;").gsub(/</, "&lt;")
    end
    
    help "get a snippet of ancient unix wisdom"
    C :f do |client,text,nick,chan|
      f = `fortune`.split($/)
      f[0] = "#{nick}: #{f[0]}"
      f
    end
    
    def parse_quote(text)

      if text[/(\d+),(\d+)(.*?)$/]
        lines = $1
        back  = $2
        title = $3
      elsif text[/(\d+)(.*?)$/]
        back  = 0
        lines = $1
        title = $2
      end
      
      [
        (lines.to_i rescue 0),
        (back.to_i  rescue 0),
        (title.lstrip rescue '')
      ]
    end
    
    help "num_lines[,back] [title] - quote n lines, starting m lines back"
    C :q do |client,text,nick,chan|
      begin
        lines,back,title = parse_quote(text)
        conversation = client.messages[back,lines].reverse.map {|l| l * ': '} * $/
        post_link = tumblr_client.create_tumble('conversation',{
          'conversation' => conversation,
          'title' => "#{title} (quoted by #{nick} on #{chan})"
        })
      
        "#{nick}: posted to #{post_link}"
      rescue
        "#{nick}: failed to post your quote: #{$!}"
      end
    end
    
    help "post: I can understand some different kinds of input - http://link [caption] (flickr photo pages," +
      "youtube video pages, just a link)" +
      " - quotes (you quoting someone else, you quoting you)"
    C() do |client,text,nick,chan|
      begin
        t = tumblr_client
        post_link = t.create_automatic_tumble(text,nick,chan)
        
        "#{nick}: posted to #{post_link}"
      rescue
        "#{nick}: I couldn't post your tumble :( #{$!}"
      end
    end
    
  end
  
  module Actions
    
    OWE_RE = /^
      (thanks|owes)
      \s+
      ([\w_]+)
      \s+
      for
      \s+
      (.*?)
    $/x
    A(OWE_RE) do |client,text,nick,chan|
      begin
        f = Faces::Client.new
        text[OWE_RE]

        response = f.thank(nick,$2,$3)

        "#{nick}: #{response}"
      rescue
        "#{nick}: i couldn't owe your beer: #{$!}"
      end
    end
  end
end

module Tumblr
  module Interpreters
    
    # pinched from erb
    def h(s)
      s.to_s.gsub(/&/, "&amp;").gsub(/\"/, "&quot;").gsub(/>/, "&gt;").gsub(/</, "&lt;")
    end
    
    FLICKR_RE = /
      ^
      http:\/\/
      (?:\w+\.|)
      flickr\.com\/photos\/
      \w+
      \/
      (\d+)
    /x
    
    help ""
    I FLICKR_RE do |client,text,nick,chan|
      url,caption = text.split(/\s+/,2)
      
      url[FLICKR_RE]
      photo_id = $1
      
      doc = Hpricot(open("http://api.flickr.com/services/rest/?method=flickr.photos.getSizes&api_key=#{$config.flickr_api_key}&photo_id=#{photo_id}"))
      source = (doc % "size[3]")['source']
      
      ['photo',{
        :source => source,
        :caption => "<a href='#{url}'>#{h(caption)}</a> (#{nick} on #{chan})"
      }]
    end
    
    YOUTUBE_RE = /
      ^
      http:\/\/
      .*?
      youtube\.com
    /x 
    I YOUTUBE_RE do |client,text,nick,chan|
      url,caption = text.split(/\s+/,2)
      ['video',{
        :embed => url,
        :caption => "<a href='#{url}'>#{h(caption)}</a> (#{nick} on #{chan})"
      }]
    end
    
    I /^http:\/\// do |client,text,nick,chan|
      url,caption = text.split(/\s+/,2)
      ['link', {
        'url' => url,
        'description' => "#{h(caption)} (#{nick} on #{chan})" }]
    end
    
    I(/^([\w_]+): /) do |client,text,nick,chan|
      text[pattern]
      quoted = $1
      text.sub!(pattern,'')
      
      ['quote',{
        'quote' => h(text),
        'source' => "#{quoted} quoted by #{nick} on #{chan}"
      }]
    end
    
    I() do |client,text,nick,chan|
      ['quote',{
        'quote' => h(text),
        'source' => "#{nick} on #{chan}"
      }]
    end
  end
end
//
//  MenuView.m
//  CoreAnimationMenu
//
//  Created by Tim Lucas (http://toolmantim.com) on 2/12/07.
//
//  Implementation of:
//  http://developer.apple.com/documentation/Cocoa/Conceptual/CoreAnimation_guide/Articles/Headstart.html
//
//  Line-by-line from the article minus the typos and code-style inconsistencies
//
//  Copyright (c) 2007 Apple Computer, Inc.
//  All rights reserved.

#import "MenuView.h"

@implementation MenuView

@synthesize selectedIndex;
@synthesize menusLayer;
@synthesize selectionLayer;
@synthesize names;

- (void)awakeFromNib
{
    names = [[NSArray arrayWithObjects:@"Item 1", @"Item 2", @"Item 3", @"Item 4", @"Item 5", nil] retain];
    [self setupLayers];
}

-(void)setupLayers;
{
    CGFloat width = 400.0;
    CGFloat height = 50.0;
    CGFloat spacing = 20.0;
    CGFloat fontSize = 32.0;
    CGFloat initialOffset = 100.0;
    
    [[self window] makeFirstResponder:self];
    
    QCCompositionLayer* rootLayer = [QCCompositionLayer compositionLayerWithFile:[[NSBundle mainBundle] pathForResource:@"Background" ofType:@"qtz"]];
    [self setLayer:rootLayer];
    [self setWantsLayer:YES];
    
    menusLayer = [CALayer layer];
    menusLayer.frame = rootLayer.bounds;
    menusLayer.layoutManager =[CAConstraintLayoutManager layoutManager];

    [rootLayer addSublayer:menusLayer];
    
    NSInteger i;
    for (i=0;i<[names count];i++) {
      NSString *name = [names objectAtIndex:i];

      CATextLayer *menuItemLayer = [CATextLayer layer];

      menuItemLayer.string = name;
      menuItemLayer.font = @"Lucida-Grande";
      menuItemLayer.fontSize = fontSize;
      menuItemLayer.foregroundColor = CGColorCreateGenericRGB(1.0,1.0,1.0,1.0);

      [menuItemLayer addConstraint:[CAConstraint
           constraintWithAttribute:kCAConstraintMaxY
                        relativeTo:@"superlayer"
                         attribute:kCAConstraintMaxY
                            offset:-(i*height+spacing+initialOffset)]];
      [menuItemLayer addConstraint:[CAConstraint constraintWithAttribute:kCAConstraintMidX
                                                              relativeTo:@"superlayer"
                                                               attribute:kCAConstraintMidX]];
           
      [menusLayer addSublayer:menuItemLayer];
    }
    
    [menusLayer layoutIfNeeded];
    
    selectionLayer = [CALayer layer];
    selectionLayer.bounds = CGRectMake(0.0,0.0,width,height);
    selectionLayer.borderWidth = 2.0;
    selectionLayer.borderColor = CGColorCreateGenericRGB(1.0f,1.0f,1.0f,1.0f);
    selectionLayer.cornerRadius = height/2;
    
    CIFilter *filter = [CIFilter filterWithName:@"CIBloom"];
    [filter setDefaults];
    [filter setValue:[NSNumber numberWithFloat:5.0] forKey:@"inputRadius"];
    [filter setName:@"pulseFilter"];
    
    [selectionLayer setFilters:[NSArray arrayWithObject:filter]];
    
    CABasicAnimation* pulseAnimation = [CABasicAnimation animation];
    pulseAnimation.keyPath = @"filters.pulseFilter.inputIntensity";
    pulseAnimation.fromValue = [NSNumber numberWithFloat: 0.0];
    pulseAnimation.toValue = [NSNumber numberWithFloat: 1.5];
    pulseAnimation.duration = 1.0;
    pulseAnimation.repeatCount = 1e100f;
    pulseAnimation.autoreverses = YES;
    pulseAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];

    [selectionLayer addAnimation:pulseAnimation forKey:@"pulseAnimation"];

    [rootLayer addSublayer:selectionLayer];
    
    [self changeSelectedIndex:0];
}

-(void)changeSelectedIndex:(NSInteger)theSelectedIndex
{
    selectedIndex=theSelectedIndex;
 
    if (selectedIndex == [names count])
    {
      selectedIndex = [names count]-1;
    }
    else if (selectedIndex < 0)
    {
      selectedIndex = 0;
    }
 
    selectionLayer.position = [(CALayer*)[[menusLayer sublayers] objectAtIndex:selectedIndex] position];
};

-(void)moveUp:(id)sender
{
    [self changeSelectedIndex:selectedIndex-1];
}
-(void)moveDown:(id)sender
{
    [self changeSelectedIndex:selectedIndex+1];
}

-(void)dealloc
{
    [menusLayer release];
    [selectionLayer release];
    [names release];
    [super dealloc];
}

@end

//
//  MenuView.h
//  CoreAnimationMenu
//
//  Created by Tim Lucas (http://toolmantim.com) on 2/12/07.
//
//  Sample code for the example Core Animation Menu Application:
//  http://developer.apple.com/documentation/Cocoa/Conceptual/CoreAnimation_guide/Articles/Headstart.html
//
//  Line-by-line from the article minus the typos and code-style inconsistencies
//
//  Copyright (c) 2007 Apple Computer, Inc.
//  All rights reserved.

#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>

@interface MenuView : NSView {
    // contains the selected menu item index
    NSInteger selectedIndex;
 
    // the layer that contains the menu item layers
    CALayer *menusLayer;
 
    // the layer that is used for the selection display
    CALayer *selectionLayer;
 
    // the array of menu item names
    NSArray *names;
}

@property NSInteger selectedIndex;
@property(retain) CALayer *menusLayer;
@property(retain) CALayer *selectionLayer;
@property(retain) NSArray *names;

-(void)awakeFromNib;
-(void)setupLayers;
-(void)changeSelectedIndex:(NSInteger)theSelectedIndex;
-(void)moveUp:(id)sender;
-(void)moveDown:(id)sender;
-(void)dealloc;

@end
